public abstract class Cars implements InterfaceCars 
{
    private String noOfSeats;
    private String company;
    private String model;
    private final int rentPerDay = 0;
    private String regNum;
    private boolean isRented;

    public Cars(String noOfSeats, String company, String model, String regNum, boolean isRented) {
        this.noOfSeats = noOfSeats;
        this.company = company;
        this.model = model;
        this.regNum = regNum;
        this.isRented = isRented;
    }
    
    @Override
    public String getNoOfSeats() {
        return noOfSeats;
    }

    @Override
    public String getCompany() {
        return company;
    }

    @Override
    public String getModel() {
        return model;
    }

    @Override
    public int getRentPerDay() {
        return rentPerDay;
    }

    @Override
    public String getRegNum() {
        return regNum;
    }

    @Override
    public boolean getIsRented() {
        return isRented;
    }
    public void setIsRented(boolean isRented) {
        this.isRented = isRented ;
    }

    public void setNoOfSeats(String noOfSeats) {
        this.noOfSeats = noOfSeats;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public void setModel(String model) {
        this.model = model;
    }

    

    public void setRegNum(String regNum) {
        this.regNum = regNum;
    }

    

    
    
    
}
