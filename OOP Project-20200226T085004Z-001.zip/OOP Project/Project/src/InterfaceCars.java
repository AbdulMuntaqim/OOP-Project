public interface InterfaceCars 
{
    public String getNoOfSeats();
    
    public int getRentPerDay();
    
    public String getCompany();
    
    public String getModel();
    
    public String getRegNum();
    
    public boolean getIsRented();
    
    
}
