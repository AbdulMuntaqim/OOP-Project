public class Customer 
{
    private String name ;
    private String idCardNo ;
    private long phoneNo;
    private int daysForRent;

    public Customer(String name, long phoneNo, int daysForRent) {
        this.name = name;
        this.phoneNo = phoneNo;
        this.daysForRent = daysForRent;
    }

    public String getName() {
        return name;
    }

    public String getIdCardNo() {
        return idCardNo;
    }

    public long getPhoneNo() {
        return phoneNo;
    }

    public int getDaysForRent() {
        return daysForRent;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setIdCardNo(String idCardNo) {
        this.idCardNo = idCardNo;
    }

    public void setPhoneNo(long phoneNo) {
        this.phoneNo = phoneNo;
    }

    public void setDaysForRent(int daysForRent) {
        this.daysForRent = daysForRent;
    }
    
}
