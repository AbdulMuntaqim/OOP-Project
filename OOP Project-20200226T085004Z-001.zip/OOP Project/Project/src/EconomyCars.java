public class EconomyCars extends Cars
{
    private final int rentPerDay = 1500 ;
    
    public EconomyCars(String noOfSeats, String company, String model, String regNum, boolean isRented)
    {
        super(noOfSeats, company, model, regNum, isRented);
    }

    public int getRentPerDay() {
        return rentPerDay;
    }

    
}
